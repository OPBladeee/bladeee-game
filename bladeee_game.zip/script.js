let balance = 1000;

function placeBet() {
  const betInput = document.getElementById("betAmount");
  const message = document.getElementById("message");
  let amount = parseInt(betInput.value);

  if (isNaN(amount) || amount <= 0) {
    message.textContent = "❗ Bet must be a positive number.";
    return;
  }

  if (amount > balance) {
    message.textContent = "💸 You don't have enough bladeee_coins!";
    return;
  }

  const outcome = Math.random() < 0.5 ? "win" : "lose";

  if (outcome === "win") {
    balance += amount;
    message.textContent = `🎉 You won ${amount} bladeee_coins!`;
  } else {
    balance -= amount;
    message.textContent = `😢 You lost ${amount} bladeee_coins.`;
  }

  updateBalance();
}

function checkBalance() {
  document.getElementById("message").textContent = "Just checked your balance!";
  updateBalance();
}

function updateBalance() {
  document.getElementById("balance").textContent = `💰 Balance: ${balance} bladeee_coins`;
}